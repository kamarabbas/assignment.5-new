//
//  ViewController.swift
//  Toolbar
//
//  Created by syed fazal abbas on 28/03/23.
//
import UIKit

class ViewController: UIViewController {

    var toolbar: UIToolbar!
    var barButtonItem1: UIBarButtonItem!
    var barButtonItem2: UIBarButtonItem!
    var barButtonItem3: UIBarButtonItem!
    var barButtonItem4: UIBarButtonItem!

    override func viewDidLoad() {
        super.viewDidLoad()

        toolbar = UIToolbar(frame: CGRect(x: 0, y: view.frame.size.height - 50, width: view.frame.size.width, height: 50))
        toolbar.backgroundColor = .lightGray
        view.addSubview(toolbar)

        barButtonItem1 = UIBarButtonItem(title: "Button 1", style: .plain, target: self, action: #selector(button1Tapped(_:)))
        barButtonItem2 = UIBarButtonItem(title: "Button 2", style: .plain, target: self, action: #selector(button2Tapped(_:)))
        barButtonItem3 = UIBarButtonItem(title: "Button 3", style: .plain, target: self, action: #selector(button3Tapped(_:)))
        barButtonItem4 = UIBarButtonItem(title: "Button 4", style: .plain, target: self, action: #selector(button4Tapped(_:)))
        toolbar.items = [barButtonItem1, barButtonItem2,barButtonItem3,barButtonItem4]
    }
    @objc func button1Tapped(_ sender: UIBarButtonItem) {
        print("Button 1 tapped")
    }
    @objc func button2Tapped(_ sender: UIBarButtonItem) {
        print("Button 2 tapped")
    }
    @objc func button3Tapped(_ sender: UIBarButtonItem) {
        print("Button 3 tapped")
    }
    @objc func button4Tapped(_ sender: UIBarButtonItem) {
        print("Button 4 tapped")
    }
    func addBarButtonItem(title: String, action: Selector) {
        let newBarButtonItem = UIBarButtonItem(title: title, style: .plain, target: self, action: action)
        toolbar.items?.append(newBarButtonItem)
    }
    func removeBarButtonItem(index: Int) {
        toolbar.items?.remove(at: index)
    }
    func updateBarButtonItemTitle(index: Int, newTitle: String) {
        toolbar.items?[index].title = newTitle
    }

}

