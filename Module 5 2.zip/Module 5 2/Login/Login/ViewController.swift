//
//  ViewController.swift
//  Login
//
//  Created by abbas on 28/03/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtUserName: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var tabbar: UITabBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        hideTabBar()
    }
    @IBAction func btnSubmit(_ sender: Any) {
        let username = self.txtUserName.text
        let password = self.txtPassword.text
        
        // Check if the username and password are valid
        if username == "admin" && password == "password" {
            showTabBar()
        } else {
            // If they are not valid, show an error message
            let alertController = UIAlertController(title: "Error", message: "Invalid username or password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    func hideTabBar() {
        tabbar.isHidden = true
    }
    func showTabBar() {
        tabbar.isHidden = false
    }
}

