//
//  ViewController.swift
//  Registration Form
//
//  Created by  abbas on 28/03/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtFName: UITextField!
    @IBOutlet var txtLName: UITextField!
    @IBOutlet var txtEmailID: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var txtConfirmPassword:
    UITextField!
    
    @IBOutlet var txtNumber: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnRegistration(_ sender: Any) {
        guard let firstName = txtFName.text, !firstName.isEmpty, validateName(firstName) else {
            let alertController = UIAlertController(title: "Error", message: "Please enter your First name.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let lastName = txtLName.text, !lastName.isEmpty,validateName(lastName) else {
            let alertController = UIAlertController(title: "Error", message: "Please enter your Last name.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let email = txtEmailID.text, !email.isEmpty, validateEmail(email) else {
            let alertController = UIAlertController(title: "Error", message: "Please enter Valid Email id.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
            return
            
        }
        guard let number = txtNumber.text, !number.isEmpty, validatePhone(number) else {
            let alertController = UIAlertController(title: "Error", message: "Please enter Valid Number.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
            return
            
        }
        guard let password = txtPassword.text, !password.isEmpty, validatePassword(password) else {
            let alertController = UIAlertController(title: "Error", message: "Please enter Six Digit Password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
            return
            
        }
        
        guard let confirmPassword = txtConfirmPassword.text, !confirmPassword.isEmpty, validateConfirmPassword(password, confirmPassword: confirmPassword) else {
            let alertController = UIAlertController(title: "Error", message: "Please Enter Same Password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
            return
            
        }
        submitFormData(Fname: firstName, Lname: lastName, email: email, password: password,confirmpassword: confirmPassword)
    }
    func validateName(_ name: String) -> Bool {
        let nameRegex = "^[a-zA-Z ]+$"
        let namePredicate = NSPredicate(format:"SELF MATCHES %@", nameRegex)
        return namePredicate.evaluate(with: name)
    }

    func validatePhone(_ phone: String) -> Bool {
        let phoneRegex = "^[0-9]+$"
        let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegex)
        return phonePredicate.evaluate(with: phone)
    }

    func validateEmail(_ email: String) -> Bool {
        let emailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }

    func validatePassword(_ password: String) -> Bool {
        return password.count >= 6
    }

    func validateConfirmPassword(_ password: String, confirmPassword: String) -> Bool {
        return password == confirmPassword
    }
    func submitFormData(Fname: String,Lname: String, email: String, password: String, confirmpassword: String) {
        showAlert(title: "Success", message: "Your form has been submitted successfully.")
    }
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    






}


