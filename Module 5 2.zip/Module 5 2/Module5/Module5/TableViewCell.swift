//
//  TableViewCell.swift
//  Module5
//
//  Created by  abbas on 27/03/23.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var myimg: UIImageView!
    @IBOutlet var myView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
