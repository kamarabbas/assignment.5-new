//
//  ViewController.swift
//  Module5
//
//  Created by  abbas on 27/03/23.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet var mytableView: UITableView!
    @IBOutlet var myView: UIView!
    var imgArray = Array<String>()
    override func viewDidLoad() {
        super.viewDidLoad()
        mytableView.delegate = self
        mytableView.dataSource = self
        imgArray = ["Ahmedabad","Hyderabad","Delhi","Lucknow","Azamgarh","Kolkata","Ahmedabad","Hyderabad","Delhi","Lucknow","Azamgarh","Kolkata"]
    }
}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mytableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.myimg?.image = UIImage(named: imgArray[indexPath.row])
        cell.myView.layer.cornerRadius = 10
        cell.myView.layer.masksToBounds = true
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let shareAction = UIContextualAction(style: .normal, title: "Share") { (action, view, completionHandler) in
            let itemToShare = self.imgArray[indexPath.row]
            let activityViewController = UIActivityViewController(activityItems: [itemToShare], applicationActivities: nil)
            if let popoverPresentationController = activityViewController.popoverPresentationController {
                popoverPresentationController.sourceView = view
                popoverPresentationController.sourceRect = view.bounds
            }
            self.present(activityViewController, animated: true, completion: nil)
            completionHandler(true)
        }
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
            self.imgArray.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            completionHandler(true)
        }
        shareAction.backgroundColor = .systemBlue
        deleteAction.backgroundColor = .red
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction ,shareAction])
        return swipeConfiguration
    }
}
